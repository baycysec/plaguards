# WAJIB PERHATIIN ULANG STATIC/ASSETS

[1] ADA NAMA YANG DIUBAH
[2] ADA FILE YANG DIHAPUS

===============================================

# HTML dan CSS

[-] Bisa dirapikan kembali jika ingin
