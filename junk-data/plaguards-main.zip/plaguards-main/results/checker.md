---
title: ""
author: "PLAGUARDS"
date: "IOC Report"
titlepage: true
titlepage-rule-color: "FFFFFF"
titlepage-text-color: "FFFFFF"
page-background: "/app/results/background.png"
toc: true
toc-own-page: true
titlepage-background: "/app/results/ioc-bg.pdf"
...


# VirusTotal Domain Report for donate.v2.xmrig.com
- **Last Analysis Stats**: {'malicious': 2, 'suspicious': 3, 'undetected': 30, 'harmless': 59, 'timeout': 0}
- **Reputation**: -1
- **Tags**: 

